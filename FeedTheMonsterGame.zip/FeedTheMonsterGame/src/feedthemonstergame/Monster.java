/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package feedthemonstergame;

import java.util.ArrayList;
import java.util.List;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Polygon;

/**
 *
 * @author Malak
 */
public class Monster extends Polygon{
    private double xPosition;
    private double yPosition;
    private String strokeColor;
    private double strokeWidth;
    private ImagePattern fill;
    private ArrayList<Image> images = new ArrayList<>();
    
    Monster(double x1, double y1, double x2, double y2, double x3, double y3){
        super(x1, y1, x2, y2, x3, y3);
    }
    
    public void setXPosition(double x){
        xPosition = x;
        this.setLayoutX(xPosition);
    }
    public double getXPosition(){
        return xPosition;
    }
    public void setYPosition(double y){
        yPosition = y;
        this.setLayoutY(yPosition);
    }
    public double getYPosition(){
        return yPosition;
    }
    public void setStrokeColor(String code){
        strokeColor = code;
        this.setStroke(Color.web(code));
    }
    public String getStrokeColor(){
        return strokeColor;
    }
    public void setsStrokeWidth(double w){
        strokeWidth = w;
        this.setStrokeWidth(strokeWidth);
    }
    public double returnStrokeWidth(){
        return strokeWidth;
    }
    public void setsFill(ImagePattern f){
        fill = f;
        this.setFill(fill);
    }
    public ImagePattern returnFill(){
        return fill;
    }
    public void addImage(Image i){
        images.add(i);
    }
    public Image getImage(int index){
        return images.get(index);
    }
    public void changeColor(){
        //random number will be index of image
        int randomColorIndex = 0;
        while(images.get(randomColorIndex) == fill.getImage())
            randomColorIndex =(int) (Math.random() * 4);
        fill = new ImagePattern(images.get(randomColorIndex));
        this.setFill(fill);
    }
    public void changePosition(){
        double randomX = 50 + Math.random()*1000; //random number from 50 to around 1050 (accounting for when size changes too)
        double randomY = 50 + Math.random()*600; //random integer from 50 to around 650 (accounting for when size changes too)
        //Edge-handling and changing location 
        List<Double> points = this.getPoints();
        double centerX = (points.get(0) + points.get(2) + points.get(4)) / 3.0;
        double centerY = (points.get(1) + points.get(3) + points.get(5)) / 3.0;
        this.setLayoutX(randomX-centerX);
        this.setLayoutY(randomY-centerY);
    }
    public void changeSize(){
        this.setScaleX(this.getScaleX()*1.15);
        this.setScaleY(this.getScaleX()*1.15);
    }
    public void reset(){
        this.setXPosition(600);//centers monster horizontally
        this.setYPosition(400);//centers monster vertically
        this.setStrokeColor("#D01271");
        this.setsStrokeWidth(2);
        this.setScaleX(this.getScaleX()*(1/Math.pow(1.15, 5)));
        this.setScaleY(this.getScaleY()*(1/Math.pow(1.15, 5)));
    }
}
