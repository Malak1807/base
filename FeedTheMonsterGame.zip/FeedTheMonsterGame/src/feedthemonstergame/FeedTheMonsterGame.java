/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMain.java to edit this template
 */
package feedthemonstergame;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.scene.shape.Polygon;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import java.util.List;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;


/**
 *
 * @author Malak Sohaib Salah 
 * Date: 27/5/2025
 * GUI-based program that uses JavaFX. The game begins by showing a window with a monster-looking node
 * in the middle. The monster has to be clicked five times. Every time it is clicked, it is fed, so its
 * size grows. In addition, with every click on the monster, its color changes randomly and its location
 * on the window changes randomly too. After the five clicks, a text node appears. The message displays 
 * the time elapsed from the first click to the last. On the sixth click, the game resets. 
 */
public class FeedTheMonsterGame extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        //Creating the monster node
        Monster monster = new Monster(0, 50, -50, -50, 50, -50);
        monster.setXPosition(600);//centers monster horizontally
        monster.setYPosition(400);//centers monster vertically
        monster.setStrokeColor("#D01271");
        monster.setsStrokeWidth(2);
        monster.addImage(new Image(getClass().getResourceAsStream("/feedthemonstergame/BlueHungryMonster.png")));
        monster.addImage(new Image(getClass().getResourceAsStream("/feedthemonstergame/GreenHungryMonster.png")));
        monster.addImage(new Image(getClass().getResourceAsStream("/feedthemonstergame/YellowHungryMonster2.png")));
        monster.addImage(new Image(getClass().getResourceAsStream("/feedthemonstergame/OrangeHungryMonster.png")));
        
        //Initially
        ImagePattern initial = new ImagePattern(monster.getImage(0));
        monster.setsFill(initial);
        
        //Creating text node
        Text text = new Text();
        
        //Creating the root
        Pane p = new Pane();
        
        //Adding monster node to the pane
        p.getChildren().add(monster);
        
        //Creating a scene and passing the root to it
        Scene s = new Scene(p, 1200, 800, Color.BLACK);
        
        //Stage modifications and setting the scene to the stage
        primaryStage.setTitle("Feed The Monster");
        primaryStage.setScene(s);
        
        //Declare and initialize variables to be used
        final int[] counter = {0};
        final long[] time = new long[2];
        
        //Event handling
        monster.setOnMouseClicked(e -> {
            counter[0]++;
            
            if(counter[0] == 6){
                counter[0] = 0;
                monster.reset();
                monster.setsFill(initial);
                p.getChildren().remove(text);
            }
            
            else{
                if(counter[0] == 1)
                  time[0] = System.currentTimeMillis();
 
                if(counter[0] <= 5){
                  monster.changeColor();
                  monster.changeSize();
                  monster.changePosition();
                }
            
            
                if (counter[0] == 5) {
                //Final time
                  time[1] = System.currentTimeMillis();
                
                //Message to be displayed as a node
                  text.setText("Monster is full! Time Taken: " +(time[1]-time[0])/1000.0 + " seconds");
                  text.setX(600);
                  text.setY(400);
                  text.setFill(Color.WHITE);
                  text.setStroke(Color.WHITE);
                  text.setScaleX(2);
                  text.setScaleY(2);
                  p.getChildren().add(text);
                
                }
            } 
        });
        //Showing the stage/window
        primaryStage.show();
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
    
}
