

/**
 *
 * @author Malak
 */
public class Product {
    private String name;
    private double price;
    private String category;
    
    Product(String n, double p, String c){
        this.name = n;
        this.price = p;
        this.category = c;
    }
    
    public String getName(){
        return this.name;
    }
    
    public double getPrice(){
        return this.price;
    }
    
    public String getCategory(){
        return this.category;
    }
}
