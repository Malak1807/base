import java.util.ArrayList;

/**
 *
 * @author Malak
 */
public class Customer {
    private ArrayList<Product> products = new ArrayList(0);
    private ArrayList<Transaction> transactions = new ArrayList(0);
    private static ArrayList<String> customerNames = new ArrayList(0);
    private String customerName;
    
    Customer(String name,Product...p){
        customerNames.add(name);
        customerName = name;
        
        for(int i =0; i<p.length ; i++){
            products.add(p[i]);
            
        }
        
    }
    
    public void getProducts(Product[] p){
        System.out.println();
        for(int i = 0; i < p.length ; i++ )
            System.out.println("Product name: " + p[i].getName()+"  Product Price: " + p[i].getPrice() + "  Product Category: " + p[i].getCategory());
    }
    
    public void removeProduct(String productName, Product[] p){
        int i;
        for(i = 0; i < products.size() ; i++)
          if(productName.equals(products.get(i).getName())){
              products.remove(i);
              break;
          }
        
        if(i!=p.length-1)
          for(int j = i; j < p.length-1; j++)
            p[j] = p[j+1];
        p[p.length-1] = null;
        System.out.println("Product removed");
    }
    
    public static void removeCustomer(ArrayList<Customer> c,int i){
        customerNames.remove(i);
        c.remove(i);
        
    }
    
    public void displayCustomerAndProductsDetails(){
        System.out.println();
        System.out.println("Customer name: " + customerName);
        System.out.println("Products in " + customerName + "'s bag: ");
        for(int i = 0; i < products.size() ; i++ )
            System.out.println("Product Name: " + products.get(i).getName() + "  Price: " + products.get(i).getPrice() + "  Category: " + products.get(i).getCategory());
        
    }
    
    public static void searchForCustomer(String name){
        int i;
        for (i = 0; i < customerNames.size(); i++){
          if(customerNames.get(i).equals(name)){
            System.out.println("Customer number " + i);
            break;
          }
        }
        
        if(i == customerNames.size())
        System.out.println("Customer does not exist");
    }
    
    public static void searchForProduct(String productName, Product...p){
        int i;
        for (i = 0; i < 9; i++){
          if(p[i].getName().equals(productName)){
            System.out.println("Product P" + (i+1) + " in " + p[i].getCategory() + " category");
            break;
          }
        }
        
        if(i==9)
        System.out.println("Product does not exist");
    }
    
   
}
