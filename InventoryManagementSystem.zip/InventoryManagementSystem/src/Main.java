
import java.util.ArrayList;
import java.util.Scanner;
import java.util.*;

/**
 *
 * @author Malak
 */
public class Main {
    public static void main(String[]args){
        Scanner input = new Scanner(System.in);
        
        Product p1 = new Product("iPhone", 3500, "Electronics");
        Product p2 = new Product("Apple Watch", 2000, "Electronics");
        Product p3 = new Product("iPad", 1700, "Electronics");
        Product p4 = new Product("Tiramisu", 45, "Sweets");
        Product p5 = new Product("Cheesecake", 56, "Sweets");
        Product p6 = new Product("Carrot Cake", 50, "Sweets");
        Product p7 = new Product("Mascara", 85, "Makeup");
        Product p8 = new Product("Lip gloss", 35, "Makeup");
        Product p9 = new Product("Contour", 48, "Makeup");
        
        Product[] pn = {p1, p2, p3, p4, p5, p6, p7, p8, p9};
        
        String pnName[] = new String[pn.length];
        for(int i = 0 ; i < pn.length ; i++)
            pnName[i] = pn[i].getName();
        
        double pnPrice[] = new double[pn.length];
        for(int i = 0 ; i<pn.length ; i++)
            pnPrice[i] = pn[i].getPrice();
        
        System.out.println("\nSort products based on:");
        System.out.println("1.Name (alphabetically)\n2.Price\n3.Category");
        
        boolean ch = true;
        int c;
        do{
            System.out.print("Enter your choice by number: ");
            c = input.nextInt();
            if (c != 1 && c != 2 && c != 3){
                System.out.println("Invalid choice. Try again.");
                ch = false;
            }
        }while(ch == false);
        
        switch(c){
            case 1: 
              Arrays.sort(pnName, String.CASE_INSENSITIVE_ORDER);
                for (int i = 0; i < pnName.length; i++) {
                    for (int j = 0; j < pn.length; j++) {
                        if (pnName[i].equals(pn[j].getName())) {
                            System.out.println("P" + (j+1) + ": " + pn[j].getName() + "   Price:" + " AED " + pn[j].getPrice() + "   Category: " + pn[j].getCategory());
                            break;
                        }
                    }
                }
                break;
            case 2:
                Arrays.sort(pnPrice);
                for(int i = 0 ; i < pnPrice.length ; i++){
                    for(int j = 0 ; j < pn.length ; j++){
                        if(pnPrice[i] == pn[j].getPrice()){
                            System.out.println("P" + (j+1) + ": "+ pn[j].getName() + "   Price:" + " AED " + pn[j].getPrice() + "   Category: " + pn[j].getCategory());
                            break;
                        }
                    }
                }
                break;
            case 3:
                System.out.println("\nCATEGORY 1: Electronics");
                System.out.println("P1: iPhone   Price: AED 3500");
                System.out.println("P2: Apple Watch   Price: AED 2000");
                System.out.println("P3: iPad   Price: AED 1700");
                System.out.println("\nCATEGORY 2: Sweets");
                System.out.println("P4: Tiramisu   Price: AED 45");
                System.out.println("P5: Cheesecake   Price: AED 56");
                System.out.println("P6: Carrot Cake   Price: AED 50 ");
                System.out.println("\nCATEGORY 3: Makeup");
                System.out.println("P7: Mascara   Price: AED 85");
                System.out.println("P8: Lip gloss   Price: AED 35");
                System.out.println("P9: Contour   Price: AED 48");
                break;
          
        }
        
        
        ArrayList<String> customerNames = new ArrayList(0);
        int count = -1 ;
        ArrayList<ArrayList<Product>> products = new ArrayList<>(); 
        String newCustomer = "yes";
        String p;
        boolean in = true;
        
        do{
            if(newCustomer.equals("yes") && in == true){
                products.add(new ArrayList<>());
                count++;
                System.out.print("\nCustomer name :");
                customerNames.add(input.next());
            }
            System.out.print("\nWrite pn to add a product to your basket; n is the item number: ");
            p = input.next().toLowerCase();
            
            if(p.equals("p1")|| p.equals("p2")|| p.equals("p3")|| p.equals("p4")|| p.equals("p5")|| p.equals("p6")|| p.equals("p7")|| p.equals("p8")|| p.equals("p9")){
                switch(p){
                    case "p1":
                        products.get(count).add(p1);
                        break;
                    case "p2":
                        products.get(count).add(p2);
                        break;
                    case "p3":
                        products.get(count).add(p3);
                        break;
                    case "p4":
                        products.get(count).add(p4);
                        break;
                    case "p5":
                        products.get(count).add(p5);
                        break;
                    case "p6":
                        products.get(count).add(p6);
                        break;
                    case "p7":
                        products.get(count).add(p7);
                        break;
                    case "p8":
                        products.get(count).add(p8);
                        break;
                    case "p9":
                        products.get(count).add(p9);
                        break;
                }
                in = true;
            }
            
            else{
                System.out.println("Invalid Input.");
                in = false;
                continue;
            }
            
            do{
                if(!newCustomer.equals("yes") && !newCustomer.equals("no") && !newCustomer.equals("0"))
                    System.out.println("Invalid input. Try Again.");
                System.out.print("\nNew Customer? Enter yes for a new one, no to continue adding products \ninto the basket of the same customer, and 0 to exit: ");
                newCustomer = input.next().toLowerCase();
            }while(!newCustomer.equals("yes") && !newCustomer.equals("no") && !newCustomer.equals("0"));
            
            
        }while(!newCustomer.equals("0"));
        
        ArrayList<Customer> customers = new ArrayList(0);
        int pCount = 0;
        
        for(int i = 0; i <= count ; i++){
            Product[] pr = products.get(i).toArray(new Product[products.get(i).size()]);
            customers.add(new Customer(customerNames.get(i),pr )); 
        }
        
        Product[][] pr2 = new Product [customers.size()][];
        
        for(int i = 0 ; i <= count; i++){
            pr2 [i]= new Product[products.get(i).size()];
            for (int j = 0 ; j < products.get(i).size() ; j++){
              pr2 [i][j] = products.get(i).get(j);
            }
        }

        
        System.out.println("\n1.Display the prodcuts in a costumer's basket.");
        System.out.println("2.Remove a prodcut.");
        System.out.println("3.Remove a customer.");
        System.out.println("4.Display the details of a customer and their products.");
        System.out.println("5.Search for a customer.");
        System.out.println("6.Search for a product.");
      
        
        int a;
        int n = 0;
        do{
            System.out.print("\nChoose an action(Enter its number), or enter 0 to proceed to checkout: ");
            a = input.nextInt();
            
            input.nextLine();
            
            if(a==0)
                continue;
            
            else if(a >= 1 && a <= 4){
            System.out.println();
            for(int j = 0 ; j < customerNames.size() ; j++)
                System.out.println(j + ". " + customerNames.get(j));
                while(true){
                    System.out.print("\nChoose a customer, enter their number: ");
                    n = input.nextInt();

                    if (n >= 0 && n < customerNames.size()) {
                        break;
                    } else {
                        System.out.println("Invalid input. Try again.");
                    }
                }
            
            input.nextLine();
            }
            
            else if (a!=5 && a!=6){
                System.out.println("Invalid input.");
                continue;
            }
               
            switch(a){
                case 1: customers.get(n).getProducts(pr2[n]); break;
                case 2: 
                    System.out.print("\nEnter product name: ");
                    String name = input.nextLine();
                    customers.get(n).removeProduct(name, pr2[n]);  
                    break;
                case 3: 
                    Customer.removeCustomer(customers, n); 
                    customerNames.remove(n);
                    System.out.println("Customer removed");
                    break;
                case 4:
                    customers.get(n).displayCustomerAndProductsDetails();
                    break;
                case 5:
                    System.out.print("\nEnter the name of the customer you are looking for: ");
                    String cName = input.next();
                    Customer.searchForCustomer(cName);
                    break;
                case 6:
                    System.out.print("\nEnter the name of the product you are looking for: ");
                    String pName = input.next();
                    Customer.searchForProduct(pName, p1, p2, p3, p4, p5 ,p6, p7, p8, p9);
                    break;
                    
            }
            
        }while(a!=0);
        
        boolean t ;
        // A transaction for each customer
        ArrayList<Transaction> transactions = new ArrayList(customers.size());
        
        for(int i = 0; i < transactions.size() ; i++)
            transactions.set(i, null);
        
        n=0;
        do{
            t = false;
            for(int j = 0 ; j < customerNames.size() ; j++)
                System.out.println(j + ". " + customerNames.get(j));
            
            do{
                if(n >= customerNames.size())
                    System.out.println("Invalid input. Try again.");
                System.out.println("Transaction for customer number: ");
                n = input.nextInt();
            }while(n >= customerNames.size());
           
            System.out.print("Amount of money in your balance: ");
            double b = input.nextDouble();

            System.out.print("Is this a purchase or a return? Enter true for purchase and false for a return: ");
            boolean pu = input.nextBoolean();

            transactions.add(n, new Transaction(b, pu, products.get(n)));
            
            Customer.removeCustomer(customers, n);
            customerNames.remove(n); 
            
            if (!customers.isEmpty()) {
                System.out.println("New transaction? Enter true if yes and false if no.");
                t = input.nextBoolean();
            }
        
        }while(t);
        
    }
}
