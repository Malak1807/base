
import java.util.ArrayList;
/**
 *
 * @author Malak
 */
public class Transaction {
    private double customerBalance;
    private boolean purchase;
    
    Transaction(double b, boolean p, ArrayList<Product> pr){
        purchase = p;
        customerBalance = b;
        double price = 0; 
        for(int i = 0; i < pr.size() ; i++)
            price += pr.get(i).getPrice();
        if (purchase)
            if (customerBalance >= price) {
                customerBalance -= price;
            } else {
                System.out.println("Unsufficient amount. Sorry your purchase cannot be processed.");
            }
        else
            customerBalance += price;
    }
}
