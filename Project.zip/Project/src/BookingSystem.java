
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;


/**
 *
 * @author Malak Sohaib Salah 
 * Date: 4/6/2025
 * A system for booking and managing services. Students book services/facilities, while staff manage them. 
 */
public class BookingSystem extends Application{
    
    //BookingSystem properties
    private final ArrayList<Long> IDList = new ArrayList<>();
    private final ArrayList<User> userList = new ArrayList<>();
    private final ArrayList<String> passwordList = new ArrayList<>();
    private final Facility gym = new Facility(1, "gym", "1 month memebership at the gym", 500, 50, "GYM", "gym", "8am to 9:59am", "2pm to 3:59pm");
    private final Facility chemistryLab = new Facility(2, "Chemistry Lab", "semester-length membership", 700, 30, "CHEM", "lab", "10am to 11:59am", "4pm to 5:59pm");
    private final Facility meetingRoom = new Facility(3, "Meeting room", "Room for meetings", 50, 5, "MEE", "room", "8am to 9:59am", "12pm to 1:59pm");
    private final Facility studioRoom = new Facility(4, "Studio", "Studio for film-making and creative works", 150, 10, "STD", "room","4pm to 5:59pm", "6pm to 7:59pm");
    private final Facility libraryServices = new Facility(5, "Library", "Find, read, and borrow books", 0, 40, "LIB", "library" ,"8am to 9:95am", "10am to 11:59am"); 
    private final Facility computerLab = new Facility(6, "Computer lab", "Premium facility. Access to campus computers.", 0, 80, "CSL", "lab", "10am to 11:59am");
    private final ArrayList<Facility> facilitiesList = new ArrayList<>();
    
    //Four windows: registration, log in, dashboards
    public static void main(String[] args){
        launch();
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        try{
            PrintWriter w = new PrintWriter(Facility.getFacilitiesFile());
            for(int i = 0 ; i < facilitiesList.size() ; i++){
                w.write(facilitiesList.get(i).getName());
                w.write(facilitiesList.get(i).getDescription());
                w.write(facilitiesList.get(i).getBookingFee() + "");
                w.write(facilitiesList.get(i).getOccupancyLimit());
                w.write(facilitiesList.get(i).getBuilding());
                w.write(facilitiesList.get(i).getType());
                for(int x = 0 ; x < facilitiesList.get(i).getAvailibilityTimeSlots().size() ; i++){
                    w.write(facilitiesList.get(i).getAvailibilityTimeSlots().get(x));
                }
            }
        }catch(FileNotFoundException ex){
            System.out.println(ex.getMessage());
        }
        Registration();
    }
    
    public void Registration(){
        //Create nodes
        //labels
        Label nameL = new Label("Name :");
        Label emailL = new Label("Email :");
        Label majorOrDepartmentL = new Label("Major(if student), Department(if staff) :");
        Label passwordL = new Label("Password :");
        
        //text fields
        TextField nameT = new TextField();
        TextField emailT = new TextField();
        TextField majorOrDepartmentT = new TextField();
        
        //password field
        PasswordField passwordT = new PasswordField();
        
        //radio buttons
        RadioButton ifStudent = new RadioButton("Student");
        RadioButton ifStaff = new RadioButton("Staff");
        ToggleGroup group = new ToggleGroup();
        ifStudent.setToggleGroup(group);
        ifStaff.setToggleGroup(group);
        ifStudent.setSelected(true);
        
        //buttons
        Button registerButton = new Button("Register");
        Button loginPageButton = new Button("Go to log in page");
        
        //Create pane
        GridPane p = new GridPane();
        p.setAlignment(Pos.CENTER);
        p.setHgap(10);
        p.setVgap(10);
        
        //Add nodes to pane
        //Add label nodes
        p.add(nameL, 0, 0);
        p.add(emailL, 0, 1);
        p.add(majorOrDepartmentL, 0, 2);
        p.add(passwordL, 0, 3);
        
        //Add textfield nodes
        p.add(nameT, 1, 0);
        p.add(emailT, 1, 1);
        p.add(majorOrDepartmentT, 1, 2);
        p.add(passwordT, 1, 3);
        
        //Add radio button nodes
        p.add(ifStudent, 0, 4);
        p.add(ifStaff, 1, 4);
        
        //Add button nodes
        p.add(registerButton, 0, 5);
        p.add(loginPageButton, 1, 5);
        
        //Event handling for buttons
        registerButton.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event) {
                //Generates a random number from 00000 to 99,999
                long ID = (long)(Math.random() * 100000);
                
                //adds newly generated id to id list
                IDList.add(ID);
                
                //adds entered password to password list
                passwordList.add(passwordT.getText());
                
                if(((RadioButton)group.getSelectedToggle()).getText().equals("Student")){
                    //creating student object and adding it to userList
                    Student newStudent = new Student(ID, nameT.getText(), emailT.getText(), majorOrDepartmentT.getText(), passwordT.getText());
                    userList.add(newStudent);
                    
                    //printing randomly generated ID
                    System.out.println("You ID is: " + ID);
                    
                    //openning log in window
                    Login();
                    
                    //getting the stage
                    Stage stage = (Stage)registerButton.getScene().getWindow();
                   
                    //closing registration window 
                    stage.close();
                }
                else{
                    //creating a staff object and adding it to userList
                    Staff newStaff = new Staff(ID, nameT.getText(), emailT.getText(), majorOrDepartmentT.getText(), passwordT.getText());
                    userList.add(newStaff);
                    
                    //printing randomly generated ID
                    System.out.println("You ID is: " + ID);
                    
                    //openning log in window
                    Login();
                    
                    //getting the stage
                    Stage stage = (Stage)registerButton.getScene().getWindow();
                   
                    //closing registration window 
                    stage.close();
                }
            }
            
        });
        loginPageButton.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event) {
                Login();
            }
            
        });
        
        //Create scene and pass the pane to it
        Scene s = new Scene(p, 500, 250);
        
        //Create and set stage
        Stage regStage = new Stage();
        regStage.setScene(s);
        regStage.setTitle("Registration");
        
        //Show stage
        regStage.show();
    }
    
    public void Login(){
        //Create nodes
        //labels
        Label IDL = new Label("ID : ");
        Label passwordL = new Label("Password: ");
        
        //text field
        TextField IDT = new TextField();
        
        //password field
        PasswordField passwordP = new PasswordField();
        
        //text
        Text incorrectCredentials = new Text("Incorrect Credentials!");
        incorrectCredentials.setFill(Color.TRANSPARENT);
        
        //Buttons
        Button login = new Button("Log in");
        Button register = new Button("Go to Registration");
        RadioButton ifStudent = new RadioButton("Student");
        RadioButton ifStaff = new RadioButton("Staff");
        ToggleGroup group = new ToggleGroup();
        ifStudent.setToggleGroup(group);
        ifStaff.setToggleGroup(group);
        
        //Create pane
        GridPane p = new GridPane();
        p.setAlignment(Pos.CENTER);
        p.setHgap(10);
        p.setVgap(10);
        
        //Add nodes to pane
        p.add(IDL, 0, 0);
        p.add(passwordL, 0, 1);
        p.add(IDT, 1, 0);
        p.add(passwordP, 1, 1);
        p.add(login, 0, 3);
        p.add(ifStudent, 0, 2);
        p.add(ifStaff, 1, 2);
        p.add(incorrectCredentials, 0, 4);
        p.add(register, 1, 3);
        
        //Event Handler for log in button
        login.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event) {
                if(User.verifyLogin(IDList, passwordList, IDT, passwordP)){
                    incorrectCredentials.setFill(Color.TRANSPARENT);
                    
                    //checks if the radiobutton student is selected
                    boolean student = ((RadioButton)group.getSelectedToggle()).getText().equals("Student");
                    
                    //opens a new window
                    FacilitiesAndSearch(Long.parseLong(IDT.getText()), student, event);
                }
                else{
                    //message changes colors from transparent to red
                    incorrectCredentials.setFill(Color.RED);
                }
            }
            
        });
        
        //Event handling for register button
        register.setOnAction(e ->{
            Registration();
        });
        
        //Create scene
        Scene s = new Scene(p, 500, 250);
        
        //Create and set stage
        Stage loginStage = new Stage();
        loginStage.setTitle("Log in");
        loginStage.setScene(s);
        
        //show stage
        loginStage.show();
    }
    
    public void FacilitiesAndSearch(long ID, boolean student, ActionEvent l){
        //Create pane
        GridPane p = new GridPane();
        p.setAlignment(Pos.CENTER);
        p.setHgap(2);
        p.setVgap(2);
        
        //Create first node
        Text listingFacilities = new Text("Facilities:");
        listingFacilities.setStyle("-fx-font-weight: bold; -fx-text-decoration: underline;");
        listingFacilities.setFont(Font.font(15));
        p.add(listingFacilities, 0, 0);
        
        //Add facilities to list
        if (facilitiesList.isEmpty()) {
        facilitiesList.add(gym);
        facilitiesList.add(chemistryLab);
        facilitiesList.add(meetingRoom);
        facilitiesList.add(studioRoom);
        facilitiesList.add(libraryServices);
        facilitiesList.add(computerLab);
        }
        
        //Display facility properties by creating Text nodes and adding them to pane individually
        int row = 1;
        for (int i = 0; i < facilitiesList.size(); i++){
            Text nameItem = new Text(facilitiesList.get(i).getName());
            p.add(new Label("Name of facility: "), 0, row);
            p.add(nameItem, 1, row);
            row++;
            
            Text descriptionItem = new Text(facilitiesList.get(i).getDescription());
            p.add(new Label("Description: "), 0, row);
            p.add((descriptionItem), 1, row);
            row++;
            
            Text bookingFeeItem = new Text(Double.toString(facilitiesList.get(i).getBookingFee()));
            p.add(new Label("Booking Fee: "), 0, row);
            p.add((bookingFeeItem), 1, row);
            
            
            Text occupancyLimitItem = new Text(Integer.toString(facilitiesList.get(i).getOccupancyLimit()));
            p.add(new Label("Occupancy Limit: "), 2, row-2);
            p.add((occupancyLimitItem), 3, row-2);
            row++;
            
            Text buildingItem = new Text(facilitiesList.get(i).getBuilding());
            p.add(new Label("Building Code: "), 2, row-2);
            p.add((buildingItem), 3, row-2);
            row++;
            
            Text typeItem = new Text(facilitiesList.get(i).getType());
            p.add(new Label("Type: "), 2, row-2);
            p.add((typeItem), 3, row-2);
            
            
            p.add(new Label("Available Time Slots: "), 4, row-4);
            for(int j = 0; j < facilitiesList.get(i).getAvailibilityTimeSlots().size() ; j++){
                Text availibilityTimeSlotsItem = new Text(facilitiesList.get(i).getAvailibilityTimeSlots().get(j));
                p.add((availibilityTimeSlotsItem), 5, row-4);
                row++;
            }
            row+=5;
        }
        
        //search section
        Text searchBy = new Text("Search by:");
        searchBy.setStyle("-fx-font-weight: bold; -fx-text-decoration: underline;");
        searchBy.setFont(Font.font(15));
        p.add((searchBy), 0, ++row);
        
        RadioButton time = new RadioButton("Time");
        RadioButton type = new RadioButton("Type");
        RadioButton buildingCode = new RadioButton("Building code");
        
        p.add((time), 0, ++row);
        p.add((type), 1, row);
        p.add((buildingCode), 2, row);
        
        ToggleGroup group = new ToggleGroup();
        time.setToggleGroup(group);
        type.setToggleGroup(group);
        buildingCode.setToggleGroup(group);
        
        TextField searchField = new TextField();
        p.add((searchField), 0, ++row);
        
        Button searchButton = new Button("Search");
        p.add((searchButton), 1, row);
        
        FacilitySearchEngine searchEngine = new FacilitySearchEngine();
        
        //an arraylist of facilities that matched the search
        ArrayList<Facility> matchingFacilities = new ArrayList<>();
        
        //event handler for search button
        searchButton.setOnAction(e -> {
            if(((RadioButton)group.getSelectedToggle()).getText().equals("Time")){
                //clearing the arraylist so that resuts from previuos search do not overlap with new results
                matchingFacilities.clear();
                matchingFacilities.addAll(searchEngine.searchByAvailibilityTimeSlots(facilitiesList, searchField.getText()));
            }
            else if(((RadioButton)group.getSelectedToggle()).getText().equals("Type")){
                matchingFacilities.clear();
                matchingFacilities.addAll(searchEngine.searchByType(facilitiesList, searchField.getText()));
            }
            else{
                matchingFacilities.clear();
                matchingFacilities.addAll(searchEngine.searchByBuilding(facilitiesList, searchField.getText()));
            }
            
            if(student)
                try {
                    studentDashboard(ID, matchingFacilities);
            } catch (FacilityLimitExceededException ex) {
            } catch (AccessDeniedException2 ex) {
            } catch (TimeSlotUnavailableException ex) {
            }
            else
                try{
                    staffDashboard(ID, matchingFacilities);
                }catch(TimeSlotUnavailableException ex){
                }
                
        });
        
        //Create scene
        Scene s = new Scene(p, 800, 600);
        
        //Create and set stage
        Stage st = new Stage();
        st.setScene(s);
        st.setTitle("Facilities and Search");
        st.show();
        
    }
    
    public void studentDashboard(long ID, ArrayList<Facility> matchingFacilities) throws FacilityLimitExceededException, AccessDeniedException2, TimeSlotUnavailableException{
        //create pane
        GridPane gP = new GridPane();
        gP.setAlignment(Pos.CENTER);
        gP.setHgap(2);
        gP.setVgap(2);
        
        Text searchResults = new Text("Search Results: ");
        searchResults.setStyle("-fx-font-weight: bold; -fx-text-decoration: underline;");
        searchResults.setFont(Font.font(15));
        gP.add(searchResults, 0, 0);
        
        
        //Getting the user whose id has been passed from log in
        int u;
        for(u = 0; u < IDList.size() ; u++){
            if(IDList.get(u) == ID){
                break;
            }
        }
        
        final int user = u;
        final int[] row = {1};
        
        //An arraylist of checkboxes
        ArrayList<CheckBox> checkboxes = new ArrayList<>();
        
        //for-loop iterating through facilities that matched the search
        for(int i = 0; i < matchingFacilities.size() ; i++){
            final int index = i;
            CheckBox result = new CheckBox (matchingFacilities.get(index).getName());
            checkboxes.add(result);
            gP.add(result, 0, row[0]);
            row[0]+=2;
            
            //arraylist for extra nodes 
            ArrayList<Node> extraNodes = new ArrayList<>();
 
            //adding event handler for every checkbox
            result.setOnAction( e->{
                 
                if(result.isSelected()){
                    try{
                        handleSelection(matchingFacilities, index, result, user);
               
                            Text choosePrompt = new Text("Select a time slot for the " + matchingFacilities.get(index).getName() + " facility");
                            gP.add(choosePrompt, 0, row[0]);
                            extraNodes.add(choosePrompt);
                            row[0]+=2;
                            
                            //Toggle group for radio buttons
                            ToggleGroup tS = new ToggleGroup();

                            RadioButton timeSlot1 = new RadioButton("8am to 9:59am");
                            timeSlot1.setToggleGroup(tS);
                            extraNodes.add(timeSlot1);
                            gP.add(timeSlot1, 0, row[0]);

                            RadioButton timeSlot2 = new RadioButton("10am to 11:59am");
                            timeSlot2.setToggleGroup(tS);
                            extraNodes.add(timeSlot2);
                            gP.add(timeSlot2, 3, row[0]);
                            row[0] += 2;

                            RadioButton timeSlot3 = new RadioButton("12pm to 1:59pm");
                            timeSlot3.setToggleGroup(tS);
                            extraNodes.add(timeSlot3);
                            gP.add(timeSlot3, 0, row[0]);

                            RadioButton timeSlot4 = new RadioButton("2pm to 3:59pm");
                            timeSlot4.setToggleGroup(tS);
                            extraNodes.add(timeSlot4);
                            gP.add(timeSlot4, 3, row[0]);
                            row[0] += 2;

                            RadioButton timeSlot5 = new RadioButton("4pm to 5:59pm");
                            timeSlot5.setToggleGroup(tS);
                            extraNodes.add(timeSlot5);
                            gP.add(timeSlot5, 0, row[0]);
                           

                            RadioButton timeSlot6 = new RadioButton("6pm to 7:59pm");
                            timeSlot6.setToggleGroup(tS);
                            extraNodes.add(timeSlot6);
                            gP.add(timeSlot6, 3, row[0]);
                            row[0]+=2;
                            
                            int[] currentRow = {row[0]};
                            
                            //adding an event listener for everytime a radiobuttoon is selected from the toggle group
                            tS.selectedToggleProperty().addListener((obs, oldToggle, newToggle) -> {
                               int y;
                               for(y = 0; y < matchingFacilities.get(index).getAvailibilityTimeSlots().size() ; y++){
                                  if(((RadioButton)newToggle).getText().equals(matchingFacilities.get(index).getAvailibilityTimeSlots().get(y))){
                                      break;
                                  }
                              }
                           
                              try {
                                //method that might throw an exception  
                                handleFinalSelectionTime(matchingFacilities.get(index), y);
                                
                                //if an exception is not thrown a 'Book' button appears
                                Button bookButton = new Button("Book");
                                gP.add(bookButton, 0, currentRow[0] += 1);
                                
                                //when 'Book' button is clicked, payment window opens
                                bookButton.setOnAction(new EventHandler<ActionEvent>() {
                                    @Override
                                    public void handle(ActionEvent e) {
                                        paymentWindow(user, index, matchingFacilities);
                                    }
                                });       
                              } catch (TimeSlotUnavailableException ex) {
                              }
                              
                        
                    });
                    }catch(FacilityLimitExceededException ex){
                        
                    }catch(AccessDeniedException2 ex){
                        //checkbox is deselected if student is ineligible for premium service
                        checkboxes.get(index).setSelected(false);
                        
                        System.out.println(ex.getMessage());
                    }
                }
                
                //if checckbox is deselected
                else{
                    //timeslot radiobuttons for the unchecked facility disappear
                    for(int z = 0; z < extraNodes.size() ; z++){
                        gP.getChildren().removeAll(extraNodes.get(z));
                    }
                }
        });
        }
           
        //Create a new pane
        BorderPane bP = new BorderPane();
        bP.setCenter(gP);
        
        //Create a check my services button
        Button services = new Button("Check my booked services");
        bP.setBottom(services);
        BorderPane.setMargin(services, new Insets(10));
        
        //Event handling for services button
        services.setOnAction(e ->{
            displayBookedServices(user);
        });
        
        //Create scene
        Scene s = new Scene(bP, 700, 500);
        
        //Create and set stage
        Stage stage = new Stage();
        stage.setTitle("Student Dashboard");
        stage.setScene(s);
        stage.show();
    }
   
    public void displayBookedServices(int user){
        //Pane
        GridPane p = new GridPane();
        p.setHgap(15);
        p.setVgap(15);
        p.setAlignment(Pos.CENTER);
        
        //Nodes and adding them to pane
        Text title = new Text("Your Services:");
        title.setStyle("-fx-font-weight: bold;");
        title.setFont(Font.font(15));
        p.add(title, 0, 0);
        
        int row = 1;
        try{
        for(int i = 0 ; i < ((Student)userList.get(user)).getBookedServices().size() ; i++){
            Text service = new Text(((Student)userList.get(user)).getBookedServices().get(i).getName());
            p.add(service, 0, row);
            row++;
        }}catch(ClassCastException ex){
            System.out.println(ex.getMessage());
        }
        
        //Scene
        Scene s = new Scene(p, 300, 200);
        
        //Stage
        Stage st = new Stage();
        st.setTitle("Your Booked Services");
        st.setScene(s);
        st.show();
    }
    
    public void paymentWindow(int userIndex, int index, ArrayList<Facility> f){
        //Create nodes
        Text fees = new Text("Amount due: " + f.get(index).getBookingFee());
        TextField transferredFees = new TextField("Enter amount to transfer: ");
        Button enterFee = new Button("Enter");
        
        //Add event handling for button
        enterFee.setOnAction( e -> {
        if(Double.parseDouble(transferredFees.getText()) < f.get(index).getBookingFee()){
            System.out.println("Insufficient amount! cannot process payment.");
        }
        else if(Double.parseDouble(transferredFees.getText()) > f.get(index).getBookingFee()){
            System.out.println("Extra fee! cannot process payment.");
        }
        else{
            //add service to the bookedFacilities list of the student
            try{
                ((Student) userList.get(userIndex)).addService(f.get(index));
            }catch(ClassCastException ex){
                System.out.println(ex.getMessage());
            }
            //update studentsFile.txt
            Student.updateFile(userList);
            System.out.println("Service added to the student file.");
            
            //increment occupancy of facility
            int current = f.get(index).getCurrentOccupancy();
            f.get(index).setCurrentOccupancy(++current);
        
            System.out.println("Booked successfully!");
            
            //getting stage to close the window
            Stage stage = (Stage)enterFee.getScene().getWindow();
            stage.close();
            
        }
        });
        
        //Create pane 
        VBox v = new VBox();
        v.setSpacing(10);
        
        //Add nodes to pane
        v.getChildren().add(fees);
        v.getChildren().add(transferredFees);
        v.getChildren().add(enterFee);
        
        //Adding margins
        VBox.setMargin(fees, new Insets(5));
        VBox.setMargin(transferredFees, new Insets(5));
        VBox.setMargin(enterFee, new Insets(5));
        
        //Create scene
        Scene s = new Scene(v, 300, 200);
        
        //Create and set stage
        Stage st = new Stage();
        st.setScene(s);
        st.setTitle("Payment and Booking Processing");
        st.show();
    }
    

    private void staffDashboard(long ID, ArrayList<Facility> matchingFacilities) throws TimeSlotUnavailableException{
        //create pane
        GridPane gP = new GridPane();
        gP.setAlignment(Pos.CENTER);
        gP.setHgap(2);
        gP.setVgap(2);
        
        Text searchResults = new Text("Search Results: ");
        searchResults.setStyle("-fx-font-weight: bold; -fx-text-decoration: underline;");
        searchResults.setFont(Font.font(15));
        gP.add(searchResults, 0, 0);
        
        
        //Getting the user whose id has been passed from log in
        int u;
        for(u = 0; u < IDList.size() ; u++){
            if(IDList.get(u) == ID){
                break;
            }
        }
        
        final int user = u; 
        final int[] row = {1};
        
        //An arraylist of checkboxes
        ArrayList<CheckBox> checkboxes = new ArrayList<>();
        
        //for-loop iterating through facilities that matched the search
        for(int i = 0; i < matchingFacilities.size() ; i++){
            final int index = i;
            CheckBox result = new CheckBox (matchingFacilities.get(index).getName());
            checkboxes.add(result);
            gP.add(result, 0, row[0]);
            row[0]+=2;
            
            //arraylist for extra nodes 
            ArrayList<Node> extraNodes = new ArrayList<>();
            
            result.setOnAction( e->{
                 
                if(result.isSelected()){
                    Text choosePrompt = new Text("Select a time slot for the " + matchingFacilities.get(index).getName() + " facility");
                    gP.add(choosePrompt, 0, row[0]);
                    extraNodes.add(choosePrompt);
                    row[0] += 2;

                    //Toggle group for radio buttons
                    ToggleGroup tS = new ToggleGroup();

                    RadioButton timeSlot1 = new RadioButton("8am to 9:59am");
                    timeSlot1.setToggleGroup(tS);
                    extraNodes.add(timeSlot1);
                    gP.add(timeSlot1, 0, row[0]);

                    RadioButton timeSlot2 = new RadioButton("10am to 11:59am");
                    timeSlot2.setToggleGroup(tS);
                    extraNodes.add(timeSlot2);
                    gP.add(timeSlot2, 3, row[0]);
                    row[0] += 2;

                    RadioButton timeSlot3 = new RadioButton("12pm to 1:59pm");
                    timeSlot3.setToggleGroup(tS);
                    extraNodes.add(timeSlot3);
                    gP.add(timeSlot3, 0, row[0]);

                    RadioButton timeSlot4 = new RadioButton("2pm to 3:59pm");
                    timeSlot4.setToggleGroup(tS);
                    extraNodes.add(timeSlot4);
                    gP.add(timeSlot4, 3, row[0]);
                    row[0] += 2;

                    RadioButton timeSlot5 = new RadioButton("4pm to 5:59pm");
                    timeSlot5.setToggleGroup(tS);
                    extraNodes.add(timeSlot5);
                    gP.add(timeSlot5, 0, row[0]);

                    RadioButton timeSlot6 = new RadioButton("6pm to 7:59pm");
                    timeSlot6.setToggleGroup(tS);
                    extraNodes.add(timeSlot6);
                    gP.add(timeSlot6, 3, row[0]);
                    row[0] += 2;

                    int[] currentRow = {row[0]};

                    tS.selectedToggleProperty().addListener((obs, oldToggle, newToggle) -> {
                        int y;
                        for (y = 0; y < matchingFacilities.get(index).getAvailibilityTimeSlots().size(); y++) {
                            if (((RadioButton) newToggle).getText().equals(matchingFacilities.get(index).getAvailibilityTimeSlots().get(y))) {
                                break;
                            }
                        }

                        try {
                            //method that might throw an exception
                            handleFinalSelectionTime(matchingFacilities.get(index), y);

                            //if no exception is thrown a 'Manage' button appears 
                            Button manageButton = new Button("Manage");
                            gP.add(manageButton, 0, currentRow[0] += 1);

                            manageButton.setOnAction(new EventHandler<ActionEvent>() {
                                @Override
                                public void handle(ActionEvent e) {
                                    //Adding facility to managedFacilities arraylist
                                    try{
                                        ((Staff) userList.get(user)).addFacility(matchingFacilities.get(index));
                                    }catch(ClassCastException ex){
                                        System.out.println(ex.getMessage());
                                    }
                                    //Update staffFile.txt content
                                    try {
                                        Staff.updateFile(userList);
                                    } catch (FileNotFoundException ex) {
                                       System.out.println(ex.getMessage());
                                    }
                      
                                    System.out.println("Facility added to the staff managed facilities file.");
                                    
                                    System.out.println("Facility added to your managed facilities list.");
                                }
                            });
                        } catch (TimeSlotUnavailableException ex) {
                        }
                    });

                }
                
                //if checkbox deselected
                else{
                    //timeslot radiobuttons are removed
                    for(int z = 0; z < extraNodes.size() ; z++){
                        gP.getChildren().removeAll(extraNodes.get(z));
                    }
                }
        });
        }
        
        //Create a HBox new pane
        HBox h = new HBox();
        h.setAlignment(Pos.CENTER);
        
        //Create a check facilities I manage button
        Button services = new Button("Check Facilities I Manage");
        h.getChildren().add(services);
        
        //Create a button for reading a File
        Button read = new Button("Display Student File Content");
        h.getChildren().add(read);
        
        //Create a button for reading a File
        Button readStaff = new Button("Display Staff File Content");
        h.getChildren().add(readStaff);
        
        //Create a BOrderPane that wraps the HBox pane
        BorderPane bP = new BorderPane();
        bP.setCenter(gP);
        bP.setBottom(h);
        BorderPane.setMargin(h, new Insets(10));
        
        //Event handling for services button
        services.setOnAction(e ->{
            displayManagedFacilities(user);
        });
        
        //Event handling for read button
        read.setOnAction(e->{
            Student.readFromFile();
        });
        
        //Event handling for readStaff button
        readStaff.setOnAction(e->{
            Staff.readFromFile();
            
        });
        
        //Create scene
        Scene s = new Scene(bP, 700, 500);
        
        //Create and set stage
        Stage stage = new Stage();
        stage.setTitle("Staff Dashboard");
        stage.setScene(s);
        stage.show();
    }
    
    public void displayManagedFacilities(int user){
        //pane
        GridPane p = new GridPane();
        p.setHgap(15);
        p.setVgap(15);
        p.setAlignment(Pos.CENTER);
        
        //nodes and adding them to pane
        Text title = new Text("Facilities You Manage:");
        title.setStyle("-fx-font-weight: bold;");
        title.setFont(Font.font(15));
        p.add(title, 0, 0);
        
        int row = 1;
        try{
            for(int i = 0 ; i < ((Staff)userList.get(user)).getManagedFacilities().size() ; i++){
            Text service = new Text(((Staff)userList.get(user)).getManagedFacilities().get(i).getName());
            p.add(service, 0, row);
            row++;
        }}catch(ClassCastException ex){
            System.out.println(ex.getMessage());
        
        }
        
        
        //scene
        Scene s = new Scene(p, 300, 200);
        
        //stage
        Stage st = new Stage();
        st.setTitle("Facilities You Manage");
        st.setScene(s);
        st.show();
    }
    
    
    public void handleSelection(ArrayList<Facility> matchingFacilities, int i, CheckBox r, int userIndex) throws FacilityLimitExceededException, AccessDeniedException2{
        if(matchingFacilities.get(i).getCurrentOccupancy() == matchingFacilities.get(i).getOccupancyLimit()){
            throw new FacilityLimitExceededException(matchingFacilities.get(i), r);
        }
        
        if(!(userList.get(userIndex).isEligibleForPremiumFacilities()) && matchingFacilities.get(i).getName().equals("Computer lab")){
            throw new AccessDeniedException2("Computer labs are restricted to engineering students and staff.");
        }
    }

    private void handleFinalSelectionTime(Facility f, int y) throws TimeSlotUnavailableException {
        if(f.getAvailibilityTimeSlots().size() == y)
           throw new TimeSlotUnavailableException(f);
    }
    
}