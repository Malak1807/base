
import java.util.ArrayList;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;


/**
 *
 * @author Malak
 */
public abstract class User {
    private long ID;
    private String password;
    
    User(long ID, String Password){   
    }
    
    public static boolean verifyLogin(ArrayList IDList, ArrayList passwordList, TextField IDT, PasswordField passwordP){
      
        int id;
        for (id = 0; id < IDList.size(); id++) {
            if ((IDList.get(id)).equals(Long.valueOf(IDT.getText()))) {
                break;
            }
        }
        int p;
        for (p = 0; p < passwordList.size(); p++) {
            if (passwordList.get(p).equals(passwordP.getText())) {
                break;
            }
        }
        if (id == IDList.size() || p == passwordList.size() || id != p) {
            return false;
        } else {
            return true;
        }

    }
    
    public abstract boolean isEligibleForPremiumFacilities();
}
