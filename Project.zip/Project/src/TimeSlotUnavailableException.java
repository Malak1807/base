/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Malak
 */
public class TimeSlotUnavailableException extends Exception {

    public TimeSlotUnavailableException(Facility f) {
        System.out.println("This time slot is unavailable for the " +f.getName()+ " facility");
    }
    
}
