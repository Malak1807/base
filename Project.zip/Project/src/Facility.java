
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author Malak
 */
public class Facility {
    //Declare properties
    private int ID;
    private String name;
    private String description;
    private double bookingFee;
    private int occupancyLimit;
    private String building;
    private String type;
    private ArrayList<String> availibilityTimeSlots = new ArrayList<>();
    private int currentOccupancy = 0;
    private static File facilitiesFile = new File("files/facilities.txt");
    
    //Parameterized contructor
    Facility(int ID, String name, String description, double bookingFee, int occupancyLimit, String building, String type, String ... timeSlots){
        //Initializing properties
        this.ID = ID;
        this.name = name;
        this.description = description;
        this.bookingFee = bookingFee;
        this.occupancyLimit = occupancyLimit;
        this.building = building;
        this.type = type;
        availibilityTimeSlots.addAll(Arrays.asList(timeSlots));
    }
    
    public void setID(int ID){
        this.ID = ID;
    }
    
    public int getID(){
        return ID;
    }
    
    public void setName(String name){
        this.name = name;
    }
    
    public String getName(){
        return name;
    }
    
    public void setDescription(String description){
        this.description = description;
    }
    
    public String getDescription(){
        return description;
    }
    public void setBookingFee(double bookingFee){
        this.bookingFee = bookingFee;
    }
    
    public double getBookingFee(){
        return bookingFee;
    }
    
    public void setOccupancyLimit(int occupancyLimit){
        this.occupancyLimit = occupancyLimit;
    }
    
    public int getOccupancyLimit(){
        return occupancyLimit;
    }
    
    public void setBuilding(String building){
        this.building = building;
    }
    
    public String getBuilding(){
        return building;
    }
    
    public void setType(String type){
        this.type = type;
    }
    
    public String getType(){
        return type;
    }
      
    public void setAvailibilityTimeSlots(ArrayList<String> availibilityTimeSlots) {
        this.availibilityTimeSlots = availibilityTimeSlots;
    }

    public ArrayList<String> getAvailibilityTimeSlots() {
        return availibilityTimeSlots;
    }
    
     public void addTimeSlot(String timeSlot){
        availibilityTimeSlots.add(timeSlot);
    }
    
    public void removeTimeSlot(String timeSlot){
        int i;
        for(i = 0 ; i < availibilityTimeSlots.size() ; i++){
            if(availibilityTimeSlots.get(i).equals(timeSlot))
                break;
        }
        availibilityTimeSlots.remove(i);
    }

    public void setCurrentOccupancy(int currentOccupancy) {
        this.currentOccupancy = currentOccupancy;
    }

    public int getCurrentOccupancy() {
        return currentOccupancy;
    }

    public static void setFacilitiesFile(File facilitiesFile) {
        Facility.facilitiesFile = facilitiesFile;
    }

    public static File getFacilitiesFile() {
        return facilitiesFile;
    }
    
    
    
}

