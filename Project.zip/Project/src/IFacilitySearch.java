
import java.util.ArrayList;


/**
 *
 * @author Malak
 */
public interface IFacilitySearch {
    
    ArrayList<Facility> searchByAvailibilityTimeSlots(ArrayList<Facility> FL, String text);
    
    ArrayList<Facility> searchByType(ArrayList<Facility> FL, String text);
    
    ArrayList<Facility> searchByBuilding(ArrayList<Facility> FL, String text);
}
