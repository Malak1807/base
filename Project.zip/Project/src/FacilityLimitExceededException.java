
import javafx.scene.control.CheckBox;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Malak
 */
public class FacilityLimitExceededException extends Exception {

    public FacilityLimitExceededException(Facility f, CheckBox c) {
        System.out.println("The occupancy limit for the " + f.getName() + " facility is exceeded. You cannot book this facility");
        c.setSelected(false);
    }
    
}
