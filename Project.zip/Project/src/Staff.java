
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Malak
 */
public class Staff extends User{
    private String name;
    private String email;
    private String department;
    private ArrayList<Facility> managedFacilities = new ArrayList<>();
    private static File staffFile = new File("files/staff.txt");

    public Staff(long ID, String name, String email, String department, String password) {
        super(ID, password);
        this.name = name;
        this.email = email;
        this.department = department;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public void setManagedFacilities(ArrayList<Facility> managedFacilities) {
        this.managedFacilities = managedFacilities;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getDepartment() {
        return department;
    }

    public ArrayList<Facility> getManagedFacilities() {
        return managedFacilities;
    }
    
    public void addFacility(Facility managedFacility){
        managedFacilities.add(managedFacility);
    }
    
    public void removeService(Facility managedFacility){
        int i = 0;
        for( ; i < managedFacilities.size() ; i++){
            if(managedFacilities.get(i) == managedFacility)
                break;
        }
        managedFacilities.remove(i);
    }

    public static void setStaffFile(File staffFile) {
        Staff.staffFile = staffFile;
    }

    public static File getStaffFile() {
        return staffFile;
    }
    
    public static void updateFile(ArrayList<User> userList) throws FileNotFoundException{
         //Create an arraylist of staff objects
        ArrayList<Staff> staffList = new ArrayList<>();
        for(User u: userList){
            if(u instanceof Staff)
                staffList.add((Staff)u);
        }
        
        //Update list
        try{
            PrintWriter w = new PrintWriter(Student.getStudentsFile());
            for(Staff s: staffList){
                w.write("\n\n" + s.getName());
                for(Facility b: s.getManagedFacilities()){
                    w.write(b.getName());
                }
            }
            
        }catch(FileNotFoundException ex){
            System.out.println(ex.getMessage());
        }
    }
    
    public static void readFromFile(){
        try {
                Scanner scan = new Scanner(Staff.getStaffFile());
                if(scan.hasNext()){
                    scan.next();
                }
            } catch (FileNotFoundException ex) {
                System.out.println(ex.getMessage());
            }
    }
    
    @Override
    public boolean isEligibleForPremiumFacilities(){
        return true;
    }
    
}
