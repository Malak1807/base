
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;


/**
 *
 * @author Malak
 */
public class Student extends User{
    private String name;
    private String email;
    private String major;
    private ArrayList<Facility> bookedServices = new ArrayList<>();
    private static File studentsFile = new File("files/students.txt");

    public Student(long ID, String name, String email, String major,  String password) {
        super(ID, password);
        this.name = name;
        this.email = email;
        this.major = major;
    }
    
    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public void setBookedServices(ArrayList<Facility> bookedServices) {
        this.bookedServices = bookedServices;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getMajor() {
        return major;
    }

    public ArrayList<Facility> getBookedServices() {
        return bookedServices;
    }
    
    public void addService(Facility bookedService){
        bookedServices.add(bookedService);
    }
    
    public void removeService(Facility bookedService){
        int i = 0;
        for( ; i < bookedServices.size() ; i++){
            if(bookedServices.get(i) == bookedService)
                break;
        }
        bookedServices.remove(i);
    }

    public static void setStudentsFile(File studentsFile) {
        Student.studentsFile = studentsFile;
    }

    public static File getStudentsFile() {
        return studentsFile;
    }
    
    public static void updateFile(ArrayList<User> userList){
        //Create an arraylist of student objects
        ArrayList<Student> studentList = new ArrayList<>();
        for(User u: userList){
            if(u instanceof Student)
                studentList.add((Student)u);
        }
        
        //Update list
        try{
            PrintWriter w = new PrintWriter(Student.getStudentsFile());
            for(Student s: studentList){
                w.write("\n\n" + s.getName());
                for(Facility b: s.getBookedServices()){
                    w.write(b.getName());
                }
            }
            
        }catch(FileNotFoundException ex){
            System.out.println(ex.getMessage());
        }
    }
    
    public static void readFromFile(){
        try {
                Scanner scan = new Scanner(Student.getStudentsFile());
                if(scan.hasNext()){
                    scan.next();
                }
            } catch (FileNotFoundException ex) {
                System.out.println(ex.getMessage());
            }
    }
    
    @Override
    public boolean isEligibleForPremiumFacilities(){
        if(this.major.toLowerCase().contains("engineer"))
            return true;
        else
            return false;
    }
    
}
