
import java.util.ArrayList;


/**
 *
 * @author Malak
 */
public class FacilitySearchEngine implements IFacilitySearch{
    
    
    @Override
    public ArrayList<Facility> searchByAvailibilityTimeSlots(ArrayList<Facility> FL, String text){
        ArrayList<Facility> matchingFacilities = new ArrayList<>();
        for(int i = 0; i < FL.size() ; i++){
            for(int j = 0 ; j < FL.get(i).getAvailibilityTimeSlots().size() ; j++){
                if(FL.get(i).getAvailibilityTimeSlots().get(j).contains(text))
                    matchingFacilities.add(FL.get(i));
            }
        }
        return matchingFacilities;
        
    }

    @Override
    public ArrayList<Facility> searchByType(ArrayList<Facility> FL, String text) {
        ArrayList<Facility> matchingFacilities = new ArrayList<>();
        for(int i = 0; i < FL.size() ; i++){
            if(FL.get(i).getType().contains(text)){
                matchingFacilities.add(FL.get(i));
            }
        }
        return matchingFacilities;
    }

    @Override
    public ArrayList<Facility> searchByBuilding(ArrayList<Facility> FL, String text) {
        ArrayList<Facility> matchingFacilities = new ArrayList<>();
        for(int i = 0; i < FL.size() ; i++){
            if(FL.get(i).getBuilding().contains(text)){
                matchingFacilities.add(FL.get(i));
            }
        }
        return matchingFacilities;
    }
}
