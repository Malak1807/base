
/**
 *
 * @author Malak
 */
public class AccessDeniedException2 extends Exception {

    public AccessDeniedException2(String s) {
        super(s);
        
    }
    
}
